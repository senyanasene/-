#include <DHT.h>
// Вариант 23 — метеостанция
// s1: скорость ветра (POT), 0…30 м/с
// s2: температура воздуха (NTC), -20…80 °C
// s3: влажность (DHT22), 0…100 %
const byte PIN_WIND = A0;
const byte PIN_NTC = A1;
const byte PIN_DHT = 2;
const byte PIN_BUZZER = 8;
const byte PIN_LED = 9;
const unsigned long PERIOD_MS = 3000;
const float WIND_THRESHOLD = 15.0;
DHT dht(PIN_DHT, DHT22);
unsigned long previousPoll = 0;
unsigned long measurementNumber = 0;
bool thresholdActive = false;
// Учебное допущение из задания: значение аналогового датчика линейно
// зависит от результата АЦП (0…1023).
float readScaledAnalog(byte pin, float minimum, float maximum) {
  return minimum + (maximum - minimum) * analogRead(pin) / 1023.0;
}
void setAlarm(bool enabled) {
  digitalWrite(PIN_LED, enabled ? HIGH : LOW);
  if (enabled) {
    tone(PIN_BUZZER, 1000);       // зуммер включён
  } else {
    noTone(PIN_BUZZER);           // зуммер выключен
  }
}
void printData(unsigned long n, float wind, float temperature, float humidity) {
  Serial.print("DATA n=");
  Serial.print(n);
  Serial.print(" s1=");
  Serial.print(wind, 2);
  Serial.print(" s2=");
  Serial.print(temperature, 2);
  Serial.print(" s3=");
  Serial.println(humidity, 2);
}
void printEvent(unsigned long n, const char *type) {
  Serial.print("EVENT n=");
  Serial.print(n);
  Serial.print(" type=");
  Serial.println(type);
}
void takeMeasurement() {
  measurementNumber++;
  float wind = readScaledAnalog(PIN_WIND, 0.0, 30.0);
  float temperature = readScaledAnalog(PIN_NTC, -20.0, 80.0);
  float humidity = dht.readHumidity();
  // При ошибке чтения DHT22 не выводим некорректную строку DATA.
  if (isnan(humidity)) {
    Serial.println("ERROR sensor=DHT22");
    return;
  }
  printData(measurementNumber, wind, temperature, humidity);
  const bool eventNow = wind > WIND_THRESHOLD;
  if (eventNow != thresholdActive) {
    thresholdActive = eventNow;
    setAlarm(thresholdActive);
    printEvent(measurementNumber, thresholdActive ? "THRESHOLD" : "NORMAL");
  }
}
void setup() {
  Serial.begin(9600);
  pinMode(PIN_LED, OUTPUT);
  pinMode(PIN_BUZZER, OUTPUT);
  setAlarm(false);
  dht.begin();
  takeMeasurement();
  previousPoll = millis();
}
void loop() {
  if (millis() - previousPoll >= PERIOD_MS) {
    previousPoll += PERIOD_MS;
    takeMeasurement();
  }
}
